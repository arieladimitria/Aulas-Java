package LacoRepeticao;

public class exercicio1 {

	public static void main(String[] args) {
		int x;
		for(x=1000;x<2000;x++)
		{
			if(x%11==5)
				System.out.println(x);
		}
	}
}
